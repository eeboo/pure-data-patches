hk-303
======

Something like a tb-303 to learn pure-data
